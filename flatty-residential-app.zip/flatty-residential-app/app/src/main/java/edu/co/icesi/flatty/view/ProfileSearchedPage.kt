package edu.co.icesi.flatty.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import edu.co.icesi.flatty.R
import edu.co.icesi.flatty.databinding.ActivityEditProfileBinding
import edu.co.icesi.flatty.databinding.ActivityProfileSearchedPageBinding

class ProfileSearchedPage : AppCompatActivity() {

    private lateinit var binding: ActivityProfileSearchedPageBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileSearchedPageBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_profile_searched_page)
        val view = binding.root
        binding.btnBackToSearchResident.setOnClickListener {
            var intent = Intent(this, SearchResident::class.java)
            startActivity(intent)
        }
        binding.goToFavoritos.setOnClickListener{
            var intent = Intent(this, FavouritesPages::class.java)
            startActivity(intent)
        }


    }
}